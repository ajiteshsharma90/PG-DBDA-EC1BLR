
public class VariableExample
{

	public static void main(String[] args) 
	{
	
		int id = 1001;
		String name = "nsnathan";
		String cname = "dbda";
		float dpercentage = 66.5f;
		char grade = 'A';
		boolean qualified = true;
		
		
		System.out.println("Student id  = "+ id);
		System.out.println("Student name = "+ name);
		System.out.println(cname);
		System.out.println(dpercentage);
		System.out.println(grade);
		System.out.println(qualified);
		
		
		
		
		
		
		
		
	}
	
	
}
